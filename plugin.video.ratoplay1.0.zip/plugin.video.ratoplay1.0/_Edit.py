import xbmcaddon

MainBase = 'https://pastebin.com/raw/QeM9KmSq'
addon = xbmcaddon.Addon('plugin.video.ratoplay1.0')